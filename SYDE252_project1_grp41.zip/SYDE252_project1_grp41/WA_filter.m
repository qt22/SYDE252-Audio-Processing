% Weighted average filter
function y = WA_filter(x, L)
    b = gausswin(L); % generate b coefficients based on the gaussian distribution
    b_norm = b / sum(b);
    y = filter(b_norm, 1, x);
    % wvtool(gausswin(L)); % can uncomment to visually view the b coefficients
end